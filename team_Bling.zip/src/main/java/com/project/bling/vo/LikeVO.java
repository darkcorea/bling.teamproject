package com.project.bling.vo;

public class LikeVO {

	private int interest_idx;
	private int midx;
	private int pidx;
	
	
	public int getInterest_idx() {
		return interest_idx;
	}
	public void setInterest_idx(int interest_idx) {
		this.interest_idx = interest_idx;
	}
	public int getMidx() {
		return midx;
	}
	public void setMidx(int midx) {
		this.midx = midx;
	}
	public int getPidx() {
		return pidx;
	}
	public void setPidx(int pidx) {
		this.pidx = pidx;
	}
	
}
