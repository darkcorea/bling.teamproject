package com.project.bling.vo;

public class User_gradeVO {

	private int gold;
	private int gold_bene;
	private int silver;
	private int silver_bene;
	
	
	public int getGold() {
		return gold;
	}
	public void setGold(int gold) {
		this.gold = gold;
	}
	public int getGold_bene() {
		return gold_bene;
	}
	public void setGold_bene(int gold_bene) {
		this.gold_bene = gold_bene;
	}
	public int getSilver() {
		return silver;
	}
	public void setSilver(int silver) {
		this.silver = silver;
	}
	public int getSilver_bene() {
		return silver_bene;
	}
	public void setSilver_bene(int silver_bene) {
		this.silver_bene = silver_bene;
	}
	
}
