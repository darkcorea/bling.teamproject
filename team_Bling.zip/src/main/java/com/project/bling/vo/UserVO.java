package com.project.bling.vo;

public class UserVO {

	private int midx;
	private String id;
	private String pwd;
	private String email;
	private int zip_code;
	private String addr1;
	private String addr2;
	private int phone;
	private int mileage;
	private String grade;
	private String uname;
	private String agree_sms;
	private String agree_email;
	private String agree_shopping;
	
	
	public String getAgree_sms() {
		return agree_sms;
	}
	public void setAgree_sms(String agree_sms) {
		this.agree_sms = agree_sms;
	}
	public String getAgree_email() {
		return agree_email;
	}
	public void setAgree_email(String agree_email) {
		this.agree_email = agree_email;
	}
	public String getAgree_shopping() {
		return agree_shopping;
	}
	public void setAgree_shopping(String agree_shopping) {
		this.agree_shopping = agree_shopping;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getMidx() {
		return midx;
	}
	public void setMidx(int midx) {
		this.midx = midx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getZip_code() {
		return zip_code;
	}
	public void setZip_code(int zip_code) {
		this.zip_code = zip_code;
	}
	public String getAddr1() {
		return addr1;
	}
	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}
	public String getAddr2() {
		return addr2;
	}
	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public int getMileage() {
		return mileage;
	}
	public void setMileage(int mileage) {
		this.mileage = mileage;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
}
