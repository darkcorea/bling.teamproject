package com.project.bling.vo;

public class ImageVO {

	private int image_idx;
	private int pidx;
	private String main;
	private String detail1;
	private String detail2;
	private String detail3;
	private String showing1;
	private String showing2;
	private String showing3;
	private String showing4;
	private String showing5;
	
	
	public int getImage_idx() {
		return image_idx;
	}
	public void setImage_idx(int image_idx) {
		this.image_idx = image_idx;
	}
	public int getPidx() {
		return pidx;
	}
	public void setPidx(int pidx) {
		this.pidx = pidx;
	}
	public String getMain() {
		return main;
	}
	public void setMain(String main) {
		this.main = main;
	}
	public String getDetail1() {
		return detail1;
	}
	public void setDetail1(String detail1) {
		this.detail1 = detail1;
	}
	public String getDetail2() {
		return detail2;
	}
	public void setDetail2(String detail2) {
		this.detail2 = detail2;
	}
	public String getDetail3() {
		return detail3;
	}
	public void setDetail3(String detail3) {
		this.detail3 = detail3;
	}
	public String getShowing1() {
		return showing1;
	}
	public void setShowing1(String showing1) {
		this.showing1 = showing1;
	}
	public String getShowing2() {
		return showing2;
	}
	public void setShowing2(String showing2) {
		this.showing2 = showing2;
	}
	public String getShowing3() {
		return showing3;
	}
	public void setShowing3(String showing3) {
		this.showing3 = showing3;
	}
	public String getShowing4() {
		return showing4;
	}
	public void setShowing4(String showing4) {
		this.showing4 = showing4;
	}
	public String getShowing5() {
		return showing5;
	}
	public void setShowing5(String showing5) {
		this.showing5 = showing5;
	}
	
	
	
	
}
