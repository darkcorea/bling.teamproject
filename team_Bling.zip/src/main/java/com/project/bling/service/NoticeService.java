package com.project.bling.service;

public interface NoticeService {

}
