package com.project.bling.service;

public interface MyPageService {

}
